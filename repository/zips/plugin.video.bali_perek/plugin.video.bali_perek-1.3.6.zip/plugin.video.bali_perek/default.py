# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,urlparse,pyxbmct
from xml.etree import ElementTree as xml
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
import HTMLParser,httplib,dns.resolver,socket
from open import getMediaLinkForGuest
html_parser = HTMLParser.HTMLParser()
__plugin__ = 'plugin.video.bali_perek'
Addon = xbmcaddon.Addon(id=__plugin__)
Domain=Addon.getSetting("domain")
#Domain='haperek.com'
def dictToQuery(d):
  query = ''
  for key in d.keys():
    query += str(key) + '=' + str(d[key]) + "&"
  return query
headers = {
'Host': Domain,
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.5',
'Connection': 'keep-alive',
'Upgrade-Insecure-Requests': '1',
'DNT': '1',
'Pragma': 'no-cache',
'Cache-Control': 'no-cache'
}
headers_query=dictToQuery(headers)



class MyHTTPConnection (httplib.HTTPConnection):
    def connect (self):
        
            resolver = dns.resolver.Resolver()
            resolver.nameservers = ['8.8.8.8']
            answer = resolver.query(self.host,'A')
            self.host = answer.rrset.items[0].address
            self.sock = socket.create_connection ((self.host, self.port))

class MyHTTPHandler (urllib2.HTTPHandler):
    def http_open (self, req):
        return self.do_open (MyHTTPConnection, req)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        name=clean(name)
        name=name.replace('|',' ')
        description=description.replace('|',' ')
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder,description, iconimage="DefaultFolder.png",original_name=''):
 

          
          name=name.replace('|',' ')
          description=description.replace('|',' ')
          if original_name=='':
            original_name=name

          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+(description)+"&original_name="+urllib.quote_plus(original_name)
          logging.warning(u)
          
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": description   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
class POPUPTEXT(pyxbmct.AddonDialogWindow):
    def __init__(self, title='',text=[]):
        super(POPUPTEXT, self).__init__(title)
        self.setGeometry(1200, 700, 9, 4)
        self.text=text
        self.y=0
        self.x=len(text)-1
        self.changelog = pyxbmct.TextBox(font='Small')
        self.set_active_controls()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        
        #self.changelog.controlUp(lambda:self.scroll_up)
    def fix_text(self,text):
      

      text_lines=text.splitlines()
      txt_all=''
      
      for line in text_lines:
        text_new1=line.strip()
        if ':' in text_new1:
         y=0
         text_new2=''
         for value in text_new1.split(':'):

           if y==0:
             text_new2=text_new2+'[COLOR aqua]'+value+'[/COLOR]'
           else:
             text_new2=text_new2+value
           y=y+1
         text_new=text_new2
        else:
         text_new=line
        txt_all=txt_all+text_new+'\n'
      return txt_all
    def next(self):
      if self.x<(len(self.text)-1):

        self.x=self.x+1
       

        self.changelog.setText(self.text)
    def prev(self):
     if self.x>0:
        
        self.x=self.x-1
      
        new_text=self.fix_text(self.text[self.x])
        self.changelog.setText(self.text)
    def scroll_up(self):
       self.changelog.scroll(self.y)
       self.lines_count=sum(1 for line in self.text)

       if self.y<self.lines_count:
         self.y=self.y+1
    def scroll_down(self):
       self.changelog.scroll(self.y)
       if self.y>0:
         self.y=self.y-1
    def set_active_controls(self):
        
        
        self.placeControl(self.changelog, 0, 0, 8, 8)
        self.changelog.setText(self.text)
        self.connectEventList([pyxbmct.ACTION_MOVE_DOWN],
                              self.scroll_up)
        self.connectEventList([pyxbmct.ACTION_MOVE_UP],
                              self.scroll_down)


    
        
        self.button7 = pyxbmct.Button('Close')
        self.placeControl(self.button7, 8, 3)
        # Connect control to close the window.
        self.connect(self.button7, self.close)

      
        self.setFocus(self.button7)
def read_site_html2(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html
def Crypt(value):
  import hashlib
  
  m = hashlib.md5()
  m.update(value)
  md5_1 = m.hexdigest()
  return((md5_1))
def dictToQuery(d):
  query = ''
  for key in d.keys():
    query += str(key) + '=' + str(d[key]) + ";"
  return query
def read_site_html(url_link):
    global Domain
    import requests,cookielib
    #check redirect

    
    headers = {
    #'Host': Domain,
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'DNT': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache'
    }
    
    handlers = [MyHTTPHandler]
    cookjar = cookielib.CookieJar()
    handlers += [urllib2.HTTPHandler(), urllib2.HTTPSHandler(), urllib2.HTTPCookieProcessor(cookjar)]
    opener = urllib2.build_opener(*handlers)
    request = urllib2.Request(url_link,  headers=headers)

    try:
      html = opener.open(request)
    except:
      xbmc.sleep(100)
      try:
        html = opener.open(request)
      except:
        xbmc.sleep(100)
        html = opener.open(request)
    domain=html.geturl()
    
    regex_domain='//(.+?)/'
    mathc_domain=re.compile(regex_domain).findall(domain)
    new_domain=mathc_domain[0]
    if new_domain!=Domain:
      Addon.setSetting("domain",new_domain)
      Domain=Addon.getSetting("domain")
    #xbmcgui.Dialog().ok("בא לי פרק"," כתובת האתר הוחלפה ועודכנה פתח שנית "+ '\n[COLOR aqua]'+Domain+'[/COLOR]')
    html=html.read()
    '''
    except:
      #xbmcgui.Dialog().ok("בא לי פרק","בעיה בחיבור לאתר\n החלף כתובת בהגדרות")
        logging.warning(url_link)
        r=opener.urlopen(url_link).geturl()
        #r = requests.get(url_link)
        logging.warning(r)
        regex_domain='//(.+?)/'
        mathc_domain=re.compile(regex_domain).findall(r)
        logging.warning(mathc_domain)
        new_domain=mathc_domain[0]
        if new_domain!=Domain:
          Addon.setSetting("domain",new_domain)
          Domain=Addon.getSetting("domain")
        xbmcgui.Dialog().ok("בא לי פרק"," כתובת האתר הוחלפה ועודכנה פתח שנית "+ '\n[COLOR aqua]'+Domain+'[/COLOR]')
        sys.exit()
    '''
    #html = urllib2.urlopen(request, timeout=int(30)).read()
    
    #html=requests.get(url_link,headers=headers)
    cookies={}
    for item in cookjar:
       cookies[item.name]=item.value

    #a=a+1
    try:
        
        first=Crypt('protect_own'+Domain)
        second=Crypt('protect_up'+Domain)
        third=Crypt('js'+Domain)

        oc1=str(cookies[first])
        oc2=str(cookies[second])
        
        co3=Crypt(oc1+oc2)+Crypt(oc2+oc1)



        cookies = {
        third: (co3),
        first:oc1,
        second:oc2
        }
        fixed_cookies=dictToQuery(cookies)
        headers['cookie'] =fixed_cookies
   
        request = urllib2.Request(url_link,  headers=headers)
        #html=requests.get(url_link,headers=headers,cookies=cookies)
        html = opener.open(request, timeout=int(30)).read()
        
        return html#.encode('utf8')
    except:
      return html#.encode('utf8')
    
    
   
   
USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0"
def fetch_url(url, headers={}, direct=False, size=None):
    hdr={
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        'Accept-Language': "en-US,en;q=0.5",
        'Referer': url,
        'User-Agent': USER_AGENT
    }
    hdr.update(headers)

    try:
        
        req = urllib2.Request(url, headers=hdr)
        return urllib2.urlopen(req).read(size)

    except urllib2.URLError, e:
        
        return False
        
def get_url_info(url):
   
                
    x=fetch_url('http://player.kan.org.il/live/ipbc/IPBCchannel11LVM/hls/metadata.xml?smil_profile=default&')

    xml_data = xml.XML(x)
    
    title = xml_data.find('Title').text
   

    #duration = int(xml_data.find('Duration').text)
   
    '''
    for poster in xml_data.find('PosterLinks').findall('PosterIMG'):
        poster_width = int(poster.attrib['width'])
        poster_height = int(poster.attrib['height'])
        poster_url = poster.text
        print("Poster: %sx%s: %s" % (poster_width, poster_height, poster_url))

    '''
    server = xml_data.find('CDNInfo/Servers')[0].text

    playback_url = xml_data.find('PlaybackLinks/SmilURL').text
    url_p = urlparse.urlparse(playback_url)
    url_p = url_p._replace(netloc=server)
    playback_url = urlparse.urlunparse(url_p)
    return( playback_url)
def searchInSeretil(image):
    search_entered =''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
                search_entered = keyboard.getText()

    if search_entered !='' :
        url2=(('http://%s/?s='%Domain)+search_entered.replace(' ','+'))
        
        research(search_entered.replace(' ','+'),url2)

def clean(name):
  return name.replace('בא לי פרק','').replace('לצפייה ישירה','').replace('פרק המלא !','').replace('באיכות HD!','').replace('HD!','').replace('עכשיו באתר','')
def main_menu():
    import unwise,jsunpack
    import hashlib
    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','משיג תוכן', '','')
    dp.update(0, 'מעדכן רשימה','משיג תוכן', '' )
    addNolink('[COLOR lightblue][I]חדש חדש[/I][/COLOR]', 'www',99,False)
    #try:
    #  html=read_site_html_open('http://www.bali-perek.com/')
    #except:
    #  pass
    from HTMLParser import HTMLParser
    h = HTMLParser()
    y=0
    z=0
    all_names=[]
    for x in range(1,5):
    
        main_addr='http://'+Domain
       
        html=read_site_html(main_addr+'/page/'+str(x))
      
        regex='a class="g1-frame" href="(.+?)".+?src="(.+?)".+?rel="bookmark">(.+?)<'

        match=re.compile(regex).findall(html)
     
        if len(match)>0:
         for link,image,name in match:
          name=h.unescape(name.decode('utf8')).encode('utf8')
          dp.update(int(z/(len(match)*4*100.0)), ' מוסיף '+name,str(z)+'/'+str(len(match)*4), 'עמוד ' +str(y)+'/'+"4")
          z=z+1
          #html2=read_site_html(link)
          
          #if 'class="success-msg"' in html2 or 'openload.co' in html2:
          image=image+"|"+headers_query
          name=name.replace("|","").replace(">","")
          addDir3(name,link,3,(image),image,name)
          
          #else:
          #  addDir3('[COLOR red]'+name+'[/COLOR]',link,3,image,image,name)
        else:

         
         regex='<a class="g1-frame" href="(.+?)".+?src="(.+?)" class.+? entry-title">.+?>(.+?)</a>'
           
         match=re.compile(regex,re.DOTALL).findall(html)
         
         for link,image,name in match:
            name=h.unescape(name.decode('utf8')).encode('utf8').replace("|","").replace(">","")
            dp.update(int(z/(len(match)*4*100.0)), ' מוסיף '+name,str(z)+'/'+str(len(match)*4),'עמוד ' +str(y)+'/'+"4")
            z=z+1
            if name not in all_names:
              all_names.append(name)
              addDir3(name,link,3,image,image,name)
            '''
            html2=read_site_html(link)
            if 'class="success-msg"' in html2 or 'openload.co' in html2:
                image=image+"|"+headers_query
                addDir3(name,link,3,image,image,name)
            '''
            #else:
            #    addDir3('[COLOR red]'+name+'[/COLOR]',link,3,image,image,name)
        y=y+1
    addDir3('[COLOR green]חפש[/COLOR]','www',6,'','','חפש')
    dp.close()
    regex='<li id="menu-item-.+?" class="(.+?)"><a href="(.+?)">(.+?)</a>'
    match=re.compile(regex,re.DOTALL).findall(html)
    for class_menu,link,name2 in match:
      fixed_name=h.unescape(name2.decode('utf8')).encode('utf8')
      if 'ערוץ' not in fixed_name and 'ערוץ' not in fixed_name:
          if link!='#' and 'בקרוב' not in fixed_name:
           if 'מתי הפרק' in fixed_name  :
              addNolink('[COLOR khaki]'+fixed_name+'[/COLOR]',link,7,False)
           else:
              if   'children' in class_menu:
                addNolink('[COLOR khaki][I]'+fixed_name+'[/I][/COLOR]', 'www',99,False)
              else:
               if 'movies' in link:
                  addDir3(fixed_name.replace('</a>',''),link,3,'','',fixed_name)
               else:
                  addDir3(fixed_name.replace('</a>',''),link,2,'','',fixed_name)
            
          else:
            addNolink('[COLOR aqua][I]'+ fixed_name+'[/I][/COLOR]', 'www',99,False)


def check_redirect(html):
      ok=True
      regex='direction: rtl;"><a href="(.+?)">'
      match=re.compile(regex,re.DOTALL).findall(html)

      
      if len(match)>0:
        html=read_site_html(match[0])
       
        return html
      else:
       return html

def seasons(name,url):

  from HTMLParser import HTMLParser
  h = HTMLParser()
  logging.warning(url)
  html=read_site_html(url)
  '''
  if 'rel="bookmark">' in html:
    regex='href="(.+?)">.+?src="(.+?)".+?rel="bookmark">(.+?)<'
  else:
    regex='href="(.+?)">.+?src="(.+?)".+?alt="(.+?)"'
  '''
  regex='a href="(.+?)".+?src="(.+?)" alt="(.+?)"'
  match=re.compile(regex).findall(html)

  if '<div style="display: block;">' in html:
   for link,image,name in match:
    
    if Domain not in image:
      image='http://'+Domain+image
    if Domain not in link:
      link='http://'+Domain+link
    image=image+"|"+headers_query
    addDir3(name,link,4,image,image,name)
  else:


   regex='<a class="g1-frame" href="(.+?)".+?src="(.+?)" class.+? entry-title">.+?>(.+?)</a>'
   
   match=re.compile(regex,re.DOTALL).findall(html)

   for link,image,name in match:
    name=h.unescape(name.decode('utf8')).encode('utf8')
    if Domain not in link:
      link='http://'+Domain+link
    if Domain not in image:
      image='http://'+Domain+image
    image=image+"|"+headers_query
    addDir3(str(name),link,3,image,image,str(name))


def research(name,url):
   from HTMLParser import HTMLParser
   h = HTMLParser()
   logging.warning(url)
   html=read_site_html(url)
   html=check_redirect(html)


   regex='<a class="g1-frame" href="(.+?)".+?src="(.+?)" class.+? entry-title">.+?>(.+?)</a>'
   
   match=re.compile(regex,re.DOTALL).findall(html)
   for link,image,name in match:
    name=h.unescape(name.decode('utf8')).encode('utf8')
    image=image+"|"+headers_query
    addDir3((name),link,3,image,image,(name))
  
   regex='<li class="g1-pagination-item">.+?<a href="(.+?)">(.+?)</a>'
   match=re.compile(regex,re.DOTALL).findall(html)
   for link,name in match:

      addDir3(' עמוד'+name,link,4,'','',' עמוד'+name)
def get_links(name,url,image):

  logging.warning(url)
  from HTMLParser import HTMLParser
  h = HTMLParser()
  all_links=[]
  html=read_site_html(url)
  regex='<strong>(.+?)</strong></span><br />'
  match=re.compile(regex).findall(html)
  if len(match)>0:
    addNolink( '[COLOR red]'+match[0]+'[/COLOR]', 'www',99,False)
  regex='<b>(.+?)</b></span><'
  match=re.compile(regex).findall(html)
  for names in match:
    addNolink( '[COLOR red]'+names+'[/COLOR]', 'www',99,False)
  regex='<h2 class="hTitle">(.+?)</h2>'
  plot_t=re.compile(regex,re.DOTALL).findall(html)
  try:
   plot=plot_t[0].strip(' \n').replace('<br />','')
  except:
   plot=''
  plot=(h.unescape(plot.decode('utf8'))).encode('utf8')
  regex='jwplayer.+?file: "(.+?)"'
  match=re.compile(regex,re.DOTALL).findall(html)
  count=0

  for link in match:
    all_links.append(link)
    addLink('מקור '+str(count),link,5,False,plot,(image),original_name=name)
    count=count+1
  regex='<iframe.+?src="(.+?)"'
  match=re.compile(regex,re.DOTALL).findall(html)
  
    
  for link in match:

    regex='//(.+?)/'
    match_name=re.compile(regex).findall(link)
    #if 'openload.co' in link:
    if len (match_name)>0:
        if 'http:' not in link and 'https:' not in link:
          link='http:'+link
  
        if 'groupon' not in match_name[0]:
          all_links.append(link)
          addLink(match_name[0],link,5,False,plot,image,original_name=name)
  regex='<div id="player-embed"><a href="(.+?)"'
  match=re.compile(regex,re.DOTALL).findall(html)
  
    
  for link in match:

    regex='//(.+?)/'
    match_name=re.compile(regex).findall(link)
    #if 'openload.co' in link:
    if len (match_name)>0:
        if 'http:' not in link and 'https:' not in link:
          link='http:'+link
  
        if 'groupon' not in match_name[0]:
          all_links.append(link)
          addLink(match_name[0],link,5,False,plot,image,original_name=name)
  regex='<p><script src="(.+?)"></script></p>'
  match=re.compile(regex,re.DOTALL).findall(html)
  if len(match)>0:
    html=read_site_html2('http:'+match[0])

    regex='"file": "(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)
    
    for m in match:
      all_links.append(m)
      addLink('מקור',m,5,False,plot,image)
  regex='<a href="http://www.makom.tv(.+?)"'
  match=re.compile(regex).findall(html)
  if len (match)>0:
    yy=read_site_html2('http://www.makom.tv'+match[0])
    regex='<iframe.+?src="(.+?)"'
    match2=re.compile(regex).findall(yy)
    for link in match2:

        regex='//(.+?)/'
        match_name=re.compile(regex).findall(link)
        #if 'openload.co' in link:
        if len (match_name)>0:
            if 'http:' not in link and 'https:' not in link:
              link='http:'+link
      
            if 'groupon' not in match_name[0]:
              all_links.append(link)
              addLink(match_name[0],link,5,False,plot,image,original_name=name)
def play(name,url,original_name):
  url=url.replace(" ","").replace("\n","")
  
  if 'openload'  in url or 'estream' in url or 'www.dailymotion.com' in url or 'youtube' in url or 'vidzi' in url:
     if 'openload' in url:
         streamurl=getMediaLinkForGuest(url)
         
         url2=streamurl
         '''
         Domain=Addon.getSetting("server")
         En_Domain=Addon.getSetting("serveroption")
         if 'openload' in url and  len(Domain)>0 and En_Domain=='true':
           import requests
           if 'http' not in Domain:
                  Domain='http://'+Domain
           new_serv=Domain+":8080/GetVideoUrl?url="+(url)
           new_serv=new_serv.replace("openload.co",'oload.stream').replace("embed",'f')
           logging.warning(new_serv)
           if 1:#try:
               x=requests.get(new_serv, timeout=70).content
               regex='>(.+?)<'
               url2=re.compile(regex).findall(x)[0]
               
           #except:
              
           #   import urlresolver


           #   final=urlresolver.HostedMediaFile(url)
              
           #   new_url=final.get_url()
           #   url2 = urlresolver.resolve(new_url)
         '''
     else:
      import resolveurl


      final=resolveurl.HostedMediaFile(url)
      
      new_url=final.get_url()
      url2 = resolveurl.resolve(new_url)
     
  else:
    url2=url

  listitem = xbmcgui.ListItem(path=url2)
  listitem.setInfo( type="Video", infoLabels={ "Title": original_name } )

  listitem.setProperty("IsPlayable","true")
  listitem.setPath(url2)
  xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def what_next(url):
  import datetime
  day_name=['','ראשון','שני','שלישי','רביעי','חמישי','שישי','שבת']
  today_num=(datetime.datetime.today().weekday()+2)
  html=read_site_html('http://www.bali-perek.com/daily/')
  regex='<div id="day(.+?)"(.+?)</div></a></div></div></div></div></div></div>'
  match=re.compile(regex,re.DOTALL).findall(html)
  texts=['','','','','','','','','','','']
  for day,value in match:

      texts[int(day)]=texts[int(day)]+'[COLOR aqua][I]'+day_name[int(day)]+'[/I][/COLOR]'+'\n'
      regex='.+?bold">(.+?)</span></div>.+?serTxt">(.+?)</'
      match=re.compile(regex,re.DOTALL).findall(value)
     
      
      for times,name in match:
        texts[int(day)]=texts[int(day)]+name+ ' בשעה '+times+'\n'
  x=today_num
  count=0
  text_all=''
  while(count<7):
    text_all=text_all+texts[x]
    x=x+1
    count=count+1
    if x>7:
     x=1
  window = POPUPTEXT('מתי הפרק',text_all)
  window.doModal()

  del window

        
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
original_name=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        original_name=urllib.unquote_plus(params["original_name"])
except:
        pass
   

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
      seasons(name,url)
elif mode==3:
      get_links(name,url,fanart)
elif mode==4:
      research(name,url)
elif mode==5:
      play(name,url,original_name)
elif mode==6:
      searchInSeretil(iconimage)
elif mode==7:
      what_next(url)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')


xbmcplugin.endOfDirectory(int(sys.argv[1]))

