# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json
import js2py
from Cookie import SimpleCookie
__plugin__ = 'plugin.video.sparo'
Addon = xbmcaddon.Addon(id=__plugin__)
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
Domain=kingvid = Addon.getSetting("domain")
kingvid = Addon.getSetting("kingvid")
openload = Addon.getSetting("openload")
nowvideo = Addon.getSetting("nowvideo")
streamcloud = Addon.getSetting("streamcloud")
vidto = Addon.getSetting("vidto")
vidzi = Addon.getSetting("vidzi")

logging.warning(Domain)
def get_params():
        param=[]
        
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
         
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,orginal_name='no_name'):
        name=name.replace('|'," ")
        orginal_name=orginal_name.replace('|'," ")
        logging.warning(iconimage)
        #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&orginal_name="+(orginal_name)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+str(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+str(description)+"&orginal_name="+str(orginal_name)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder,iconimage="DefaultFolder.png",orginal_name=''):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&orginal_name="+urllib.quote_plus(orginal_name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)  , "Plot": orginal_name })

          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", iconimage )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html
def get_c(url):
        
        regex=",S='(.+?)'"
        match=re.compile(regex,re.DOTALL).findall(url)
        
        jscode=\
        '''
        var s={},u,c,U,r,i,l=0,a,e=eval,w=String.fromCharCode,sucuri_cloudproxy_js='',
        S='$$$$$$';L=S.length;U=0;r='';var A='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        for(u=0;u<64;u++)
        {
            s[A.charAt(u)]=u;
            }
        for(i=0;i<L;i++)
        {
        c=s[S.charAt(i)];
        U=(U<<6)+c;
        l+=6;
        while(l>=8)
        {
        ((a=(U>>>(l-=8))&0xff)||(i<(L-2)))&&(r+=w(a));
        }}; r;
        '''
        jscode=jscode.replace('$$$$$$',match[0])
        jcode2=\
        '''
        var j,document
        j="4" + 'UxF9'.substr(3, 1) +String.fromCharCode(49) + '>a'.slice(1,2)+'51'.slice(1,2)+"3" + String.fromCharCode(56) + "fsu".slice(0,1) + "5" + "9" + '46'.slice(1,2)+"4sucur".charAt(0)+"5su".slice(0,1) +  '' +String.fromCharCode(48) + 'e' +  "" +"d".slice(0,1) +  '' +"dsucur".charAt(0)+"1" + "f" + 'RyKb'.substr(3, 1) + '' +"d" + "3" + "6su".slice(0,1) + String.fromCharCode(53) + '>tHc'.substr(3, 1) + '' +'6rL5'.substr(3, 1) +'d' +  "bsucur".charAt(0)+ '' +''+"f" +  '' +''+'pT4'.charAt(2)+ '' +''+String.fromCharCode(49) +  '' +''+"0sucur".charAt(0)+ '' +'';
        document='s'+'u'+'c'+'u'+'rsuc'.charAt(0)+ 'i'+'_'+'c'+'l'+'osuc'.charAt(0)+ 'sucuriu'.charAt(6)+'sucurd'.charAt(5) + 'p'+'r'+'sucuo'.charAt(4)+ 'x'+'ysucu'.charAt(0)  +'_'+'sucuu'.charAt(4)+ 'u'+''+'i'.charAt(0)+'dsucu'.charAt(0)  +'sucur_'.charAt(5) + '9'+'3'+'8'.charAt(0)+'su2'.charAt(2)+'asuc'.charAt(0)+'7'+'asuc'.charAt(0)+ '8'+'8'+''+"=" + j + ';path=/;max-age=86400'; 
        '''

        result=js2py.eval_js(jscode)

        result2=js2py.eval_js(result.replace('location.reload();','').replace('document.cookie','document'))

        return result2,match[0]
def read_sparo_html(url):
    import requests
    
    coockie={}
    
    cookies = {
   
    'sucuri_cloudproxy_uuid_53a9650e8': '6c3d2f947083eaa2a62370d6c90b4495',
    'laravel_session': 'xC5WAE2yuuU0L8k8pCYUQZGh6YMbsv0vjYNvhGBN',
    'XSRF-TOKEN': 'eyJpdiI6IjB3OHhLaUNzTEpSXC83ZUtZYnBQVUtnPT0iLCJ2YWx1ZSI6ImtNQWM4b2ZLSE4yN3l0VHFCNEIyMVNmQ2s5THdNdW8zS21tQmluVFVZNDFSNlpZM3UwRkptd1wvMWxnMHBVT09PM3BlMTU1TVVRdm02S3pCUXZlVjU4Zz09IiwibWFjIjoiYzcxZTM4MDU4ZmMxMGE5NjljMTdiMzBjZDI0ODcyOTEzNDc1NDBjNmU5MGQwN2JiZTZiMmNjNjZkOGUwMjhlMSJ9',
    }


    headers = {
    'Host': Domain,
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
        
    }


    x=requests.get(url, headers=headers).content
    
    if 'var s={}' in x:
      coockie2,token=(get_c(x))
      cookie = SimpleCookie()
      cookie.load(str(coockie2))

      # Even though SimpleCookie is dictionary-like, it internally uses a Morsel object
      # which is incompatible with requests. Manually construct a dictionary instead.
      cookies = {}
      for key, morsel in cookie.items():
            cookies[key] = morsel.value
      cookies['XSRF-TOKEN']=str(token)
      cookies['max-age']='86400'

      
      #cookies['X-CSRF-TOKEN'] = "wYZBYILaf7Dbw0TZDKjJ3udNO8aPUa7Bns3EQcUe"
      #cookies['XSRF-TOKEN'] = "eyJpdiI6IkVZSmViYXpCdWZwMThjSmJ6dVwvRUhRPT0iLCJ2YWx1ZSI6IkpPQkE5QW83QWc1NzMxY2VwbGR1NkM3RlRDOTJ3dGpXaFF6Q29GWENlY0NOQ3NzSTBTK2ZRN2xPeDJ6dnh5TVlnNEQwbGgweHkwXC85djllSkZ0WTVOQT09IiwibWFjIjoiNTg5Y2U1OTIzY2E0YTM5ZTYxMTY2NjBhOTI4NjhjN2MyMGU1ZDJmM2U0MmEzNDBkYThmNDQ4YzU1M2NkODY5ZCJ9"
      #cookies['laravel_session'] = "xC5WAE2yuuU0L8k8pCYUQZGh6YMbsv0vjYNvhGBN"




      x=requests.get(url, headers=headers, cookies=cookies)
      
      x.encoding = 'utf-8'
      x=x.content
   
    return x
def main_menu():
    html=read_sparo_html('http://%s/'%Domain)
    regex='<div class="nav">(.+?)</div>'
    match2=re.compile(regex,re.DOTALL).findall(html)
    regex='<li><a href="(.+?)">(.+?)</a>.+?</li>'
    match=re.compile(regex,re.DOTALL).findall(match2[0])


    for link,cat in match:
        addDir3(cat,link,2,'','',cat)
    addDir3('[COLOR khaki]חיפוש[/COLOR]','www',9,'','','חפש')
    #addNolink( '[COLOR aqua][I]קטגוריות סרטים[/I][/COLOR]', 'www',2,False)
    #url='http://sparo.live/browse/%D7%A7%D7%95%D7%9E%D7%93%D7%99%D7%94'
    #html=read_sparo_html(url)
    #regex='<ul class="zarnss">(.+?)</div>'
    #match=re.compile(regex,re.DOTALL).findall(html)
    #regex='<li><a href="(.+?)">(.+?)</a>'
    #match2=re.compile(regex,re.DOTALL).findall(match[0])
    #for link,name in match2:
    #  addDir3(name,link,2,'','',name)
    

def play_othersources(name,url):
  import urlresolver,nanscrapers
  video_info={}
  def sort_function(item):
            quality = item[1][0]["quality"]
            if quality == "1080": quality = "HDa"
            if quality == "720": quality = "HDb"
            if quality == "560": quality = "HDc"
            if quality == "HD": quality = "HDd"
            if quality == "480": quality = "SDa"
            if quality == "360": quality = "SDb"
            if quality == "SD": quality = "SDc"

            return quality
  html=read_sparo_html(url)
  regex_new='<h2>(.+?)</h2>.+?<div class="yaress">(.+?)</div>'
  match_new=re.compile(regex_new,re.DOTALL).findall(html)
  if 'season'  in (match_new[0][0]):
      title=match_new[0][0]
      regex_s_e='season (.+?) episode (.+?)$'
      match_s_e=re.compile(regex_s_e).findall(match_new[0][0])
      season=match_s_e[0][0]
      episode=match_s_e[0][1]
      
      year=match_new[0][1]


      
      link = nanscrapers.scrape_episode_with_dialog(title.split(" ")[0], int(year), int(year), int(season), int(episode),None,None)
      
  else:
      year=match_new[0][1]
      title=match_new[0][0]
      video_info={"Title": title,
              'originaltitle':title,
              'year':year
                 
                 }
     
 
      link = nanscrapers.scrape_movie_with_dialog(title, year,None, timeout=600, sort_function=sort_function)
  link=link['url']

  videoPlayListUrl = urlresolver.HostedMediaFile(url=link).resolve()

  if videoPlayListUrl:
    link=videoPlayListUrl
  listItem = xbmcgui.ListItem(name.decode('utf-8'), path=link) 
   
  listItem.setInfo(type='Video', infoLabels=video_info)

  listItem.setProperty('IsPlayable', 'true')

  xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
  

def sources(name,url,image,orginal_name):
 
      original=" ".join(orginal_name.split())
      html=read_sparo_html(url)
      #regex_new='<h2>(.+?)</h2>.+?<div class="yaress">(.+?)</div>'
      #match_new=re.compile(regex_new,re.DOTALL).findall(html)
    
    
      addLink( '[COLOR aqua][B][I]מקורות נוספים[/I][/B][/COLOR]', url,10,False, image,original)
      #regex='> צפייה </span> ישירה</h2>(.+?)"> הורדה</span> ישירה</h2>'
    
      #match=re.compile(regex,re.DOTALL).findall(html)
      all_links=[]
    #for m in match:
      addLink('[COLOR aqua][I]ניגון אוטומטי[/I][/COLOR]', url,8,False, image,original)
      regex='<div class="nowdanlad">.+?href="(.+?)".+?"qualityinfo">(.+?)</p>.+?<div.+?>(.+?)</div>.+?</i>(.+?)</div>'
      match2=re.compile(regex,re.DOTALL).findall(html)
      for link,quality,name,date in match2:
        addNolink( '[COLOR aqua][I]%s[/I][/COLOR]'%quality, 'www',0,False)
       
    
      
     

        html_source=read_sparo_html(link)
        regex_source='class="btn btn-(.+?)" href="(.+?)"'
        match_s=re.compile(regex_source).findall(html_source)
        for type,links_dip in match_s:
            match_more=[]
            if 'sparo' in links_dip:
              html_source_dip=read_sparo_html(links_dip)
              regex_source_dip='<iframe src="(.+?)"'
              match_s_dip=re.compile(regex_source_dip).findall(html_source_dip)
              regex_more='<source src="(.+?)" type="video/mp4">'
              match_more=re.compile(regex_more,re.DOTALL).findall(html_source_dip)
      
            else:
              
                regex_source_dip='class="btn btn-success" href="(.+?)"'
                match_s_dip=re.compile(regex_source_dip).findall(html_source)
            for in_link in match_s_dip:
              names=re.compile('//(.+?)/',re.DOTALL).findall(in_link)[0]
              if in_link not in all_links:
                addLink( names, in_link,5,False, image,original)
                all_links.append(in_link)
            
            for links2 in match_more:
                if 'http' in links2:
                  names=re.compile('//(.+?)/',re.DOTALL).findall(links2)[0]
                  addLink( names, links2,5,False, image,original)
     
def auto_play(name,url,image,orginal_name):
    import urlresolver
  

    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','מנסה לנגן', '')
    dp.update(0, 'מעדכן רשימה','מנסה לנגן', '' )
    html=read_sparo_html(url)
    all_links=[]
    match3=[]
    regex='<div class="nowdanlad">.+?href="(.+?)".+?"qualityinfo">(.+?)</p>.+?<div.+?>(.+?)</div>.+?</i>(.+?)</div>'
    match2=re.compile(regex,re.DOTALL).findall(html)
    
    for link,quality,name,date in match2:


        html_source=read_sparo_html(link)
        regex_source='class="btn btn-(.+?)" href="(.+?)"'
        match_s=re.compile(regex_source).findall(html_source)
        x=0
        for type,links_dip in match_s:
            
            x=x+1
            if 'sparo' in links_dip:
              html_source_dip=read_sparo_html(links_dip)
              regex_source_dip='<iframe src="(.+?)"'
              match_s_dip=re.compile(regex_source_dip).findall(html_source_dip)
              regex_more='<source src="(.+?)" type="video/mp4">'
              match_more=re.compile(regex_more,re.DOTALL).findall(html_source_dip)
      
            else:
              
                regex_source_dip='class="btn btn-success" href="(.+?)"'
                match_s_dip=re.compile(regex_source_dip).findall(html_source_dip)
            for in_link in match_s_dip:
             
              if in_link not in all_links:
                linka=(in_link)
                all_links.append(in_link)
                dp.update(int(x/(len(match2)*100.0)), 'מוסיף מקורות',str(x)+'/'+str(len(match2)), in_link )
            for links2 in match_more:
                if 'http' in links2:
                  names=re.compile('//(.+?)/',re.DOTALL).findall(links2)[0]
                  linka=(links2)
                  dp.update(int(x/(len(match2)*100.0)), 'מוסיף מקורות',str(x)+'/'+str(len(match2)), links2 )
     
                 
            
            try:
                if dp.iscanceled(): break
                x=x+1
                next_one=True
                if "kingvid" in linka and kingvid=='false':
                  next_one=False
                if "openload" in linka and openload=='false':
                  next_one=False
                if "nowvideo" in linka and nowvideo=='false':
                  next_one=False
                if "streamcloud" in linka and streamcloud=='false':
                  next_one=False
                  
                if "vidto" in linka and vidto=='false':
                  next_one=False
                if "vidzi" in linka and vidzi=='false':
                  next_one=False
                if next_one==True:
                    
                    url2=False
                    try:
                      url2 = urlresolver.resolve(linka)
                    except:
                      pass


                    if (url2):
                        link = url2.split(';;')

           
                        listitem = xbmcgui.ListItem(path=link[0])
                        listitem.setInfo( type="Video", infoLabels={ "Title": orginal_name } )
                        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

                        if len(url2) > 10:

                          if dp.iscanceled(): break
                          while not xbmc.Player().isPlaying():
                            xbmc.sleep(10) #wait until video is being played
                          dp.close()
                          return 0
                          break




            except:
                pass
    dp.close()
def get_links(name,url,image,original_name):
    html=read_sparo_html(url)

    regex='<div class="link" >.+?href="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)
   
    original=" ".join(original_name.split())
    addLink('[COLOR aqua][I]ניגון אוטומטי[/I][/COLOR]', url,8,False, image,original)
    for link in match:

      names=re.compile('//(.+?)/',re.DOTALL).findall(link)[0]
      addLink( names, link,5,False, image,original)
def scrape_site(url):
   
      from HTMLParser import HTMLParser

      h = HTMLParser()
      html=read_sparo_html(url)
    
      '''
      if url=='http://sparo.live/':
        regex='<div class="img effect2">.+?src="(.+?)".+?<div class="infoMinfo">.+?href="(.+?)">.+?<h1>(.+?)</h1>.+?<p>(.+?)</p>'
        match=re.compile(regex,re.DOTALL).findall(html)
        logging.warning(match)
        for link,image,name,plot in match:
          logging.warning(name)
          try:
            fixed_plot=h.unescape(plot.strip(' \n'))
          except:
           fixed_plot=plot.strip(' \n')

          addDir3(name,link,2,image,image,fixed_plot)
      else:
      '''
      regex='<article>(.+?)</article>'
      
      match2=re.compile(regex,re.DOTALL).findall(html)
      
      regex='<a  href="(.+?)".+?src="(.+?)".+?<h1>(.+?)</h1>.+?<br><br>(.+?)</p>'
      regex2='<a href="(.+?)">.+?src="(.+?)".+?<h1>(.+?)</h1>.+?<p>(.+?)</p>'
      regex3='<a href="(.+?)">.+?src="(.+?)".+?<h1>(.+?)</h1>(.+?)</div>'
      regex_nextpage='<ul class="pagination">.+?</span></li><li><a href="(.+?)">'
      for mat in match2:

        if '<br>' not in mat and '</p>'  in mat:
          match=re.compile(regex2,re.DOTALL).findall(mat)
        elif '</p>'  in mat:
          match=re.compile(regex,re.DOTALL).findall(mat)
        else:
          match=re.compile(regex3,re.DOTALL).findall(mat)
          
        for link,image,name,plot in match:

          try:
            fixed_plot=h.unescape(plot.strip(' \n'))
          except:
           fixed_plot=plot.strip(' \n')
          name=name.replace('&#039;',"'")
          
          image=image.replace("poster//","poster/").strip(" \n\r\t")
          
          if (('series' in link) or ('סדרות' in link)) and (' פרק' not in name):
            addDir3(name,link,6,image,image,fixed_plot,name)
          elif 'פרק' in name:
            addDir3(name,link,3,image,image,fixed_plot,name)
          else:

            
            addDir3(name,link,3,image,image,fixed_plot,name)
      match=re.compile(regex_nextpage,re.DOTALL).findall(html)
      for page in match:
          addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]',page,2,'','',page)
def play_link(url,name,orginal_name):
  import urlresolver

  final=urlresolver.HostedMediaFile(url)
  new_url=final.get_url()
  url2 = urlresolver.resolve(new_url)
  listitem = xbmcgui.ListItem(path=url2)
  listitem.setInfo( type="Video", infoLabels={ "Title": orginal_name } )

  xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
def seasons(url,name):
  html=read_sparo_html(url)

  regex1='<article>(.+?)</article>'
  match2=re.compile(regex1,re.DOTALL).findall(html)

  for m in match2:
      regex='<a href="(.+?)">.+?src="(.+?)".+?<h.+?>(.+?)</h1>.+?<span .+?>(.+?)</span>.+?<span .+?>(.+?)</span>.+?<span .+?>(.+?)</span>.+?<br><br>(.+?)</p>'
      match=re.compile(regex,re.DOTALL).findall(m)
      for link,image,name,plot1,plot2,plot3,plot4 in match:
        descrp=str(plot1.strip(' \n')+'\n'+plot2.strip(' \n')+'\n[COLOR aqua]'+plot3.strip(' \n')+'[/COLOR]\n'+plot4.strip(' \n'))
        name_new=" ".join(name.split())
        name_new=name_new.replace('|'," ")
        addDir3(name_new,link,7,image,image,descrp,name.replace('|'," "))
def episodes(url,name):

  html=read_sparo_html(url)
  regex1='<article>(.+?)</article>'
  match2=re.compile(regex1,re.DOTALL).findall(html)

  for m in match2:
    regex='<a href="(.+?)">.+?src="(.+?)".+?<h.+?>(.+?)</h1>.+?<p .+?>(.+?)</p>'
    match=re.compile(regex,re.DOTALL).findall(m)
    for link,image,name,plot in match:
      addDir3(name.replace('\n','').replace('        ',''),link,3,image,image,plot.strip(' \n'),name)
def search():
    search_entered =''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
                search_entered = keyboard.getText()

    if search_entered !='' :
          html=read_sparo_html('http://%s/searchlike?search='%Domain+search_entered)
      #try:
          results_json=json.loads(html)
          for record in results_json:
            link='http://%s/'%Domain+record['categoria_name'].replace(' ','%20').encode('utf-8')+'/'+str(record['id'])+'/'+record['title'].replace(' ','%20').encode('utf-8')
      
            if (('series' in link) or ('סדרות' in link)) and (' פרק' not in name):
                new_mode=6
            elif 'פרק' in name:
                new_mode=3
            else:
                new_mode=3
            addDir3(record['title'],link,new_mode,'http://%s/uploads/poster/'%Domain+record['img'],'http://%s/uploads/poster/'%Domain+record['img'],record['tkzier'],record['title'])
      #except:
      #   addNolink( '[COLOR aqua][I]אין תוצאות[/I][/COLOR]', 'www',0,False)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
orginal_name=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        orginal_name=urllib.unquote_plus(params["orginal_name"])
except:
        pass


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
      scrape_site(url)
elif mode==3:
      sources(name,url,iconimage,orginal_name)
elif mode==4:
      get_links(name,url,iconimage,orginal_name)
elif mode==5:
      play_link(url,name,orginal_name)
elif mode==6:
      seasons(url,name)
elif mode==7:
      episodes(url,name)
elif mode==8:
      auto_play(name,url,iconimage,orginal_name)
elif mode==9:
      search()
elif mode==10:
      play_othersources(name,url)
#xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")
xbmcplugin.setContent(int(sys.argv[1]), "movies")
xbmcplugin.endOfDirectory(int(sys.argv[1]))

