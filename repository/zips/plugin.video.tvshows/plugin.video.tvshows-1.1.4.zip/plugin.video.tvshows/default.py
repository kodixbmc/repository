# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json
import requests,time,cache,threading
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
from open import getMediaLinkForGuest
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
from thevideo import getMediaLinkForGuest_thevid,getMediaLinkForGuest_vidup
class Thread(threading.Thread):
    def __init__(self, target, *args):
        self._target = target
        self._args = args
        threading.Thread.__init__(self)
    def run(self):
        self._target(*self._args)
import HTMLParser
Domain_sparo=Addon.getSetting("domain_sp")
html_parser = HTMLParser.HTMLParser()
reload(sys)  
sys.setdefaultencoding('utf8')
global link_hdonline
link_hdonline=[]
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
save_file=os.path.join(user_dataDir,"fav.txt")
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", iconimage )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,data=' ',saved_season=' ',o_name=' ',o_description=' '):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&data="+(data)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        all_data=[]
        all_data.append(o_name)
        all_data.append(url)
        all_data.append(o_description)
        all_data.append(data)
        all_data.append(iconimage)
        all_data.append(saved_season)
        new_data=json.dumps(all_data)
        save_file=os.path.join(user_dataDir,"fav.txt")
    
        file_data=[]
        
        if os.path.exists(save_file):
            f = open(save_file, 'r')
            file_data = f.readlines()
            f.close()
        menu_items=[]
        str_e=urllib.quote_plus('$$'.join(all_data))
        if new_data  in file_data:
           
           menu_items.append(('[COLOR pink][I]הסרה[/I][/COLOR]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=19')%(sys.argv[0],str_e)))
           
        menu_items.append(('פרטים', 'Action(Info)'))
        liz.addContextMenuItems(menu_items, replaceItems=False)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok



def addLink( name, url,mode,isFolder, iconimage,fanart,description,data=' ',saved_season=' ',eng_name=' ',year=' '):

          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&data="+str(data)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)+"&saved_season="+(saved_season)+'&eng_name='+eng_name+'&year='+year
 

          
         
         
          #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": description   })

          liz.setProperty("IsPlayable","true")
          art = {}
          art.update({'poster': fanart})
          liz.setArt(art)
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):
    import requests
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    
    html=requests.get(url_link).content
    return html

def main_menu():
  
    addDir3('[COLOR lightblue][I]נוגן לאחרונה[/I][/COLOR]','http://www.tvil.me/',6,'https://previews.123rf.com/images/antonbrand/antonbrand1111/antonbrand111100008/11271469-carton-superhero-in-classic-pose-isolated-on-white-Stock-Photo.jpg','https://i.kinja-img.com/gawker-media/image/upload/s--oQmXdNDn--/c_scale,fl_progressive,q_80,w_800/wxhsm2bm3hsirm7dtahm.png','נוגן לאחרונה')
    addDir3('[COLOR cornflowerblue][I]בחר קטגוריה[/I][/COLOR]','genere',4,'http://static.businessinsider.com/image/4f5a8978eab8ea3012000061-750.jpg','https://nylon-img.imgix.net/featured_images/attachments/000/036/204/original/riverdale.png?auto=format&ch=Width%2CDPR&q=75&w=640&ixlib=js-1.1.1&cs=strip&s=f44eff6b6f8fda18fe80a922df021e4f','בחר קטגוריה')
    addDir3('[COLOR aqua][I]פרקים אחרונים[/I][/COLOR]','http://www.tvil.me/',4,'http://screenrant.com/wp-content/uploads/Supergirl-Review-Episode-2-Kara-Oil-Tanker.jpg','http://screenrant.com/wp-content/uploads/Supergirl-Review-Episode-2-Kara-Oil-Tanker.jpg','פרקים אחרונים')
    addDir3('[COLOR kakhi][I]כל הסדרות[/I][/COLOR]','http://www.tvil.me/',8,'https://pics.clipartpng.com/midle/Super_Hero_PNG_Clip_Art-1119.png','https://cdn.movieweb.com/img.news.tops/NEx6Czlz5SCWBy_1_b/Marvel-Movies-Release-Slate-2021-2022-Mcu.jpg','חיפוש')
    addDir3('[COLOR kakhi][I]לפי א-ב[/I][/COLOR]','by_a_b',8,'http://blog.universidadedoingles.com.br/wp-content/uploads/2016/08/tv-series.png','http://de.web.img3.acsta.net/newsv7/17/01/03/09/42/498137.jpg','חיפוש')
    
    addDir3('[COLOR kakhi][I]חפש[/I][/COLOR]','http://www.tvil.me/',7,'http://www.bonethefish.com/design_files/icons/tvs.png','http://data.junkee.com/wp-content/uploads/2016/08/stranger.jpg','חיפוש')
    
def all_s(url):
    all_letters_d=['1-2','א','ב','ג','ד','ה','ו','ז','ח','ט','י','כ','ל','מ','נ','ס','ע','פ','צ','ק','ר','ש','ת']
    all_letters=['1-2','\x90', '\x91', '\x92', '\x93', '\x94', '\x95', '\x96', '\x97', '\x98', '\x99', '\x9b', '\x9c', '\x9e', '\xa0', '\xa1', '\xa2', '\xa4', '\xa6', '\xa7', '\xa8', '\xa9', '\xaa']
    html=read_site_html('http://www.tvil.me/%D7%A1%D7%93%D7%A8%D7%95%D7%AA.html')
    
    regex='<div id="link-(.+?)".+?<img src="(.+?)".+?alt="(.+?)".+?window.location = "(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)
    if url=='by_a_b':
        ret = xbmcgui.Dialog().select("בחר אות",all_letters_d)
        if ret!=-1:
          f_letter=all_letters[ret]
    all_letters_de=[]
    #for value in all_letters:
    #   all_letters_de.append(value[-1:])
    #logging.warning(all_letters_de)
    for link_num,image,name,link in match:
      if url=='by_a_b':
       if f_letter=='1-2':
          if name[1].isdigit():
             name_ok=1
          else:
             name_ok=0
       else:
           if name[1]==f_letter:
              name_ok=1
           else:
             name_ok=0
      else:
        name_ok=1
      if name_ok==1:
        addDir3(name,link,2,image,image,name)
def scrape_site(name,url,image,data):
    
    
    html=read_site_html('http://www.tvil.me/'+url)
    regex='<div id="change-season-(.+?)".+?<a href="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)
    all_seasons=[]
    all_links=[]
    for season, link in match:
      all_seasons.append("עונה "+season)
      all_links.append(link)
    ret = xbmcgui.Dialog().select("בחר עונה",all_seasons)
    if ret!=-1:
      
      html=read_site_html('http://www.tvil.me/'+all_links[ret].replace("%",""))
      saved_season=all_seasons[ret]
      regex='<div id="change-episode-(.+?)".+?<a href="(.+?)"'
      match=re.compile(regex,re.DOTALL).findall(html)
      regex_plot='property="og:description" content="(.+?)"'
      match_plot=re.compile(regex_plot).findall(html)
      

      
      regex_eng='id="view-english-name">.+?<span style=.+?>(.+?)<'
      match_eng=re.compile(regex_eng).findall(html)
      
      regex_year='<div id="view-year">.+?<span>(.+?)<'
      match_year=re.compile(regex_year).findall(html)
      if len(match_plot)>0:
        plot=html_parser.unescape(match_plot[0].decode('utf-8')).encode('utf-8')
      else:
        plot=''
      for names,link in match:
        if data==' ':
          f_data=name
        else:
          f_data=data
       
      
        addLink("פרק "+names,link,3,False,image,image,plot,data=f_data,saved_season=saved_season,eng_name=match_eng[0],year=match_year[0])
    else:
      sys.exit()

def open_last():
    save_file=os.path.join(user_dataDir,"fav.txt")
    
 
    file_data=[]
    change=0
    
    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    for items in file_data:
       if len(items)>1:
        f_item=json.loads(items)
        
        html=read_site_html('http://www.tvil.me/'+f_item[1].encode('utf8'))
        regex='<div id="change-episode-(.+?)"'
        match=re.compile(regex).findall(html)
        highest=0
        for index in match:
          if int(index)>=highest:
            highest=int(index)
        regex='<div id="change-season-(.+?)"'
        match=re.compile(regex,re.DOTALL).findall(html)
        highest_s=0
        for index in match:
          if int(index)>=highest_s:
            highest_s=int(index)
            
        str_all= ' מספר פרקים לעונה זו ' + str(highest)+ ' מספר עונות ' + str(highest_s)

        episode=int(f_item[0].replace('פרק ',''))
        season=int(f_item[5].replace('עונה ',''))
        if highest_s>season or highest>episode:
           color='gold'
        else:
           color='white'
           
        addDir3('[COLOR '+color+']('+f_item[5].encode('utf8')+' - '+f_item[0].encode('utf8')+') '+f_item[3].encode('utf8')+'[/COLOR]',f_item[1].encode('utf8'),2,f_item[4].encode('utf8'),f_item[4].encode('utf8'),'[COLOR gold][I]'+str_all+'[/I][/COLOR]\n'+f_item[2].encode('utf8'),data=f_item[3].encode('utf8'),saved_season=f_item[5].encode('utf8'),o_name=f_item[0].encode('utf8'),o_description=f_item[2].encode('utf8'))
def server_data(url,original_title):
   
    name1=original_title

    res='HD'
    try:
        regex='//(.+?)/'
        match_s=re.compile(regex).findall(url)[0]
    except:
      match_s=' '
      return name1,match_s,res,False
    
    check=True
    return name1,match_s,res,check
def resolve_hdo(url,action,season,episode,original_title):
    link_hdonline=[]
    stop_all=0
    ids=url.split('-')
    id=ids[len(ids)-1]
    all_links=[]
    url='https://hdonline.is/ajax/movie/episodes/'+id
    x=requests.get(url).content
    x=x.replace("\\","")
    if action=='getEpisodeEmb':
      regex_pre='<li class="ep-item"(.+?)</li'
      match=re.compile(regex_pre).findall(x)
      x=''
      for ep in match:
        if 'Episode '+episode in ep:
          x=x+' '+ep
          
      regex='data-server=".+?" data-id="(.+?)"'
    else:
      regex='data-server=".+?" data-id="(.+?)"'
    
    match=re.compile(regex).findall(x)
    
    for eid in match:
      if stop_all==1:
            break
      url='https://hdonline.is/ajax/movie/get_embed/'+eid
      x=requests.get(url).json()

      if x['status']==True:
        name1,match_s,res,check=server_data(x['src'],original_title)
        
        if check:
          all_links.append((name1.replace("%20"," "),x['src'],match_s,res))
      
      url='https://hdo.to/ajax/movie/token?eid=%s&mid=%s'%(eid,id)
      
      x=requests.get(url).content
      regex="_x='(.+?)', _y='(.+?)'"
      match=re.compile(regex).findall(x)
      for x,y in match:
        if stop_all==1:
            break
        url='https://hdonline.is/ajax/movie/get_sources/%s?x=%s&y=%s'%(eid,x,y)
        
        x=requests.get(url).content
        if len(x)>5:
         x=json.loads(x)
         if 'playlist' in x:
             for item in  x['playlist'][0]['sources']:
                   if stop_all==1:
                    break
                  
                   if 'file' in x['playlist'][0]['tracks'][0]:
                      nam1_a=x['playlist'][0]['tracks'][0]['file'].split('/')
                      nam1=nam1_a[len(nam1_a)-1].replace('.srt','')
                      if '1080' in nam1:
                          res='1080'
                      elif '720' in nam1:
                          res='720'
                      elif '480' in nam1:
                          res='480'
                      elif '360' in nam1:
                          res='360'
                      else:
                          res='HD'
                      all_links.append((nam1.replace("%20"," "),item['file'],'VIP',res))
         else:
           if 'src' in x:
            name1,match_s,res,check=server_data(x['src'],original_title)
      
            if check:
              all_links.append((name1.replace("%20"," "),x['src'],match_s,res))
              link_hdonline=all_links
    return all_links

def resolve_flix(original_title,link,action,season,episode):
        link_hdonline=[]
        stop_all=0
        all_links=[]
        x=requests.get(link).content
        
        if action=='getEpisodeEmb':
          regex='<a href="(.+?)" class="season.+?>%s</'%season
          match=re.compile(regex).findall(x)
        
          
          x=requests.get(match[0]).content
          
          regex='<h5 class="episode-title"><a href="(.+?)episode/%s"'%episode
          match=re.compile(regex).findall(x)
          
          link=match[0]+'episode/'+episode
          x=requests.get(match[0]+'episode/'+episode).content
        token=re.findall("var tok    = '(.+?)'",x)[0]
        lid=re.findall('elid = "(.+?)"',x)[0]


        import base64
        elid = urllib.quote(base64.encodestring(str(int(time.time()))).strip())

        headers = {
            'Host': 'flixanity.mobi',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': link,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Authorization': 'Bearer false',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = [
          ('action', action),
          ('idEl', lid),
          ('token', token),
          ('nopop', ''),
          ('elid',elid),
        ]

        response2 = requests.post('https://flixanity.mobi/ajax/gonlflhyad.php', headers=headers, data=data).json()

        all_links=[]

        for links in response2:
          if stop_all==1:
            break
          server=response2[links]['type']

          regex='SRC="(.+?)"'
          match=re.compile(regex,re.IGNORECASE).findall(response2[links]['embed'])
          
          src=match[0]
        
          if 'openload.co' in server or 'streamango' in server:
              
              
              nam1,srv,res,check=server_data(src,original_title)
              
              if check:
                all_links.append((nam1.replace("%20"," "),src,srv,res))
          else:
            if '1080' in server:
              res='1080'
            elif '720' in server:
              res='720'
            elif '480' in server:
              res='480'
            elif '360' in server:
              res='360'
            else:
              res='HD'
            nam1=original_title.replace('%20',' ')
            srv=server
            all_links.append((nam1,src,srv,res))
            link_hdonline=all_links
        return all_links
def get_hdonline(tv_mode,original_title,season_n,episode_n,season,episode,year_w):
        global link_hdonline
        stop_all=0
        
 
        title=original_title

        if tv_mode=='movie':
           
         
          
       
          action='getMovieEmb'
          url='http://212.227.203.133/api_v2/code/main/movie_search_all_servers_v2.php?server=hdo_movies&q=%s&year=%s'%(original_title.lower().replace('%20','+').replace('%3a','').replace(' ','+'),year_w)
        else:
          action='getEpisodeEmb'
          url='http://212.227.203.133/api_v2/code/main/movie_search_all_servers_series_v2.php?server=is_series&q=%s&season=%s'%(original_title.lower().replace('%20','+').replace('%3a','').replace(' ','+'),season)
        headers={'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.0; S16 Build/NRD90M)',
                'Host': '212.227.203.133',
                'Connection': 'Keep-Alive',
                'Accept-Encoding': 'utf8'}

        x=requests.get(url,headers=headers).json()

        links=[]
        links2=[]
        for item in x:
          if stop_all==1:
            break
          if action=='getEpisodeEmb' and 'flixanity' not in item['url']:
            year_w=item['title_with_year']
          if  (original_title) in item['title_with_year'] and year_w in item['title_with_year']:
             
             if 'flixanity' in item['url']:
               links=resolve_flix(original_title,item['url'],action,season,episode)
             
             if 'hdo.' in item['url']:
       
               links2=resolve_hdo(item['url'],action,season,episode_n,original_title)

        mergedlist = []
        mergedlist.extend(links)
        mergedlist.extend(links2)
        link_hdonline=mergedlist
        return link_hdonline
def decode(encoded, code):
        #from https://github.com/jsergio123/script.module.urlresolver
        _0x59b81a = ""
        k = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
        k = k[::-1]

        count = 0

        for index in range(0, len(encoded) - 1):
            while count <= len(encoded) - 1:
                _0x4a2f3a = k.index(encoded[count])
                count += 1
                _0x29d5bf = k.index(encoded[count])
                count += 1
                _0x3b6833 = k.index(encoded[count])
                count += 1
                _0x426d70 = k.index(encoded[count])
                count += 1

                _0x2e4782 = ((_0x4a2f3a << 2) | (_0x29d5bf >> 4))
                _0x2c0540 = (((_0x29d5bf & 15) << 4) | (_0x3b6833 >> 2))
                _0x5a46ef = ((_0x3b6833 & 3) << 6) | _0x426d70
                _0x2e4782 = _0x2e4782 ^ code

                _0x59b81a = str(_0x59b81a) + chr(_0x2e4782)

                if _0x3b6833 != 64:
                    _0x59b81a = str(_0x59b81a) + chr(_0x2c0540)
                if _0x3b6833 != 64:
                    _0x59b81a = str(_0x59b81a) + chr(_0x5a46ef)

        return _0x59b81a
def resolve_streamango(url):
        sHtmlContent = requests.get(url).content

        r1 = re.search("srces\.push\({type:\"video/mp4\",src:\w+\('([^']+)',(\d+)", sHtmlContent)
        if (r1):
            api_call = decode(r1.group(1), int(r1.group(2)))
            api_call = 'http:' + api_call
            
            return api_call

def get_c(url):
    import js2py
    regex=",S='(.+?)'"
    s_val=re.compile(regex,re.DOTALL).findall(url)[0]

    regex="var A='(.+?)'"
    a_val=re.compile(regex,re.DOTALL).findall(url)[0]
    s={}
    L=len(s_val)
    U=0
    l=0
    a=0
    r=''
  
    for i in range(0,len(a_val)):
      s[a_val[i]]=i
    for i in range(0,len(s_val)):
     if s_val[i]!='=':
      c=s[s_val[i]]
      U=(U<<6)+c
      
      l+=6
      while (l>=8):
        l=l-8
        
        f=(U>>l)&255
        
         
        a=f;
       
        r+=chr(a);
    result2=js2py.eval_js(r.replace('location.reload();','').replace('document.cookie','document'))

    return result2,s_val
def get_c_old(url):
        import js2py
        
        regex=",S='(.+?)'"
        match=re.compile(regex,re.DOTALL).findall(url)
        
        jscode=\
        '''
        var s={},u,c,U,r,l=0,a,e=eval,w=String.fromCharCode,sucuri_cloudproxy_js='',
        S='$$$$$$';L=S.length;U=0;r='';var A='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        for(u=0;u<64;u++)
        {
            s[A.charAt(u)]=u;
            }
        var k=0,h=0;
        for(k=0;k<L;k++)
        {
        h=k
        c=s[S.charAt(h)];
        U=(U<<6)+c;
        l+=6;
        
        while(l>=8)
        {
        ((a=(U>>>(l-=8))&0xff)||(h<(L-2)))&&(r+=w(a));
        }}; r;
        
        
        '''
        
        jscode=jscode.replace('$$$$$$',match[0])
        
        jcode2=\
        '''
        var j,document
        j="4" + 'UxF9'.substr(3, 1) +String.fromCharCode(49) + '>a'.slice(1,2)+'51'.slice(1,2)+"3" + String.fromCharCode(56) + "fsu".slice(0,1) + "5" + "9" + '46'.slice(1,2)+"4sucur".charAt(0)+"5su".slice(0,1) +  '' +String.fromCharCode(48) + 'e' +  "" +"d".slice(0,1) +  '' +"dsucur".charAt(0)+"1" + "f" + 'RyKb'.substr(3, 1) + '' +"d" + "3" + "6su".slice(0,1) + String.fromCharCode(53) + '>tHc'.substr(3, 1) + '' +'6rL5'.substr(3, 1) +'d' +  "bsucur".charAt(0)+ '' +''+"f" +  '' +''+'pT4'.charAt(2)+ '' +''+String.fromCharCode(49) +  '' +''+"0sucur".charAt(0)+ '' +'';
        document='s'+'u'+'c'+'u'+'rsuc'.charAt(0)+ 'i'+'_'+'c'+'l'+'osuc'.charAt(0)+ 'sucuriu'.charAt(6)+'sucurd'.charAt(5) + 'p'+'r'+'sucuo'.charAt(4)+ 'x'+'ysucu'.charAt(0)  +'_'+'sucuu'.charAt(4)+ 'u'+''+'i'.charAt(0)+'dsucu'.charAt(0)  +'sucur_'.charAt(5) + '9'+'3'+'8'.charAt(0)+'su2'.charAt(2)+'asuc'.charAt(0)+'7'+'asuc'.charAt(0)+ '8'+'8'+''+"=" + j + ';path=/;max-age=86400'; 
        '''
        
 
        result=js2py.eval_js(jscode)
  
        result2=js2py.eval_js(result.replace('location.reload();','').replace('document.cookie','document'))
  
        return result2,match[0]
def check_cookies(url):

    from Cookie import SimpleCookie
    coockie={}
    headers = {
    'Host': Domain_sparo,
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
        
    }
    x=requests.get(url, headers=headers).content
    
    if 'var s={}' in x:
      
      coockie2,token=(get_c(x))
      cookie = SimpleCookie()
      cookie.load(str(coockie2))

      # Even though SimpleCookie is dictionary-like, it internally uses a Morsel object
      # which is incompatible with requests. Manually construct a dictionary instead.
      cookies = {}
      for key, morsel in cookie.items():
            cookies[key] = morsel.value
      cookies['XSRF-TOKEN']=str(token)
      cookies['max-age']='86400'
    return cookies
def read_sparo_html(url):
    

    



    headers = {
    'Host': Domain_sparo,
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
        
    }

    cookies=cache.get(check_cookies,3,'http://'+Domain_sparo, table='cookies_sp')
    
    x=requests.get(url, headers=headers,cookies=cookies).content
    
    if 'var s={}' in x:
      
      cookies=cache.get(check_cookies,0,url, table='cookies_sp')
      #cookies=check_cookies(url)
   
      x=requests.get(url, headers=headers, cookies=cookies)
      
      x.encoding = 'utf-8'
      x=x.content
   
    return x

def get_sp(title,name,season,episode):
          
          link_source1=[]
         
          html=read_sparo_html('http://%s/searchlike?search='%Domain_sparo+title)
          
          all_links=[]
          all_links_only=[]
          try:

            results_json=json.loads(html)
          except Exception as e:
            logging.warning(e)
            results_json=[]
            html=read_sparo_html('http://%s/searchlike?search='%Domain_sparo+name)
            try:
              results_json=json.loads(html)
            except Exception as e:
              logging.warning(e)
              results_json=[]
          
          saved_name=' '


          for record in results_json:
            saved_name=record['title']
            o_link='http://%s/'%Domain_sparo+record['categoria_name'].replace(' ','%20').encode('utf-8')+'/'+str(record['id'])+'/'+record['title'].replace(' ','%20').encode('utf-8')
            
            if (('series' in o_link) or ('סדרות' in o_link)) :
                new_mode=6

            else:
                new_mode=3

            season_title='עונה-%s'%season
            episode_title='פרק-%s'%episode
            saved_link='http://%s/'%Domain_sparo
            if season!=None and season!='%20':
    
               html=read_sparo_html(o_link)
          
               regex1='<article>(.+?)</article>'
               match2=re.compile(regex1,re.DOTALL).findall(html)
               
               for m in match2:
                  regex='<a href="(.+?)">.+?src="(.+?)".+?<h.+?>(.+?)</h1>.+?<span .+?>(.+?)</span>.+?<span .+?>(.+?)</span>.+?<span .+?>(.+?)</span>.+?<br><br>(.+?)</p>'
                  match=re.compile(regex,re.DOTALL).findall(m)
                  for link,image,name,plot1,plot2,plot3,plot4 in match:
                    descrp=str(plot1.strip(' \n')+'\n'+plot2.strip(' \n')+'\n[COLOR aqua]'+plot3.strip(' \n')+'[/COLOR]\n'+plot4.strip(' \n'))
                    name_new=" ".join(name.split())
                    name_new=name_new.replace('|'," ")
                  
                    if season_title in link :
 
                      saved_link=link
                      break
   
               html=read_sparo_html(saved_link)
               regex1='<article>(.+?)</article>'
               match2=re.compile(regex1,re.DOTALL).findall(html)
  
               for m in match2:
                    regex='<a href="(.+?)">.+?src="(.+?)".+?<h.+?>(.+?)</h1>.+?<p .+?>(.+?)</p>'
                    match=re.compile(regex,re.DOTALL).findall(m)
                    for link,image,name,plot in match:
                      name=name.replace('\n','').replace('        ','')
             
                      if episode_title+" @@@@@@@@" in link+"@@@@@@@@" :
                      
                        saved_link=link
                        break
            else:
                saved_link=o_link
            
      
            html=read_sparo_html(saved_link)
            regex='<div class="nowdanlad">.+?href="(.+?)".+?"qualityinfo">(.+?)</p>.+?<div.+?>(.+?)</div>.+?</i>(.+?)</div>'
            match2=re.compile(regex,re.DOTALL).findall(html)
            
            for link,quality,name,date in match2:

                    html_source=read_sparo_html(link)
                    regex_source='class="btn btn-(.+?)" href="(.+?)"'
                    match_s=re.compile(regex_source).findall(html_source)
                    
                    xxx=0
                    for type,links_dip in match_s:
                        match_more=[]
                    
                        
                        if Domain_sparo in links_dip:
                          try:
                              html_source_dip=read_sparo_html(links_dip)
                             
                              
                              regex_source_dip='<iframe src="(.+?)"'
                              match_s_dip=re.compile(regex_source_dip).findall(html_source_dip)
                              regex_more='<source src="(.+?)" type="video/mp4">'
                              match_more=re.compile(regex_more,re.DOTALL).findall(html_source_dip)
                          except:
                            pass
                        else:
                          
                            regex_source_dip='class="btn btn-success" href="(.+?)"'
                            match_s_dip=re.compile(regex_source_dip).findall(html_source)
                        for in_link in match_s_dip:
                          if 'http' in in_link:
                              
                              names=re.compile('//(.+?)/',re.DOTALL).findall(in_link)[0]
                              if in_link not in all_links_only:
                                all_links_only.append(in_link)
                                all_links.append((saved_name,in_link,names,quality))
                                link_source1=all_links
                        for links2 in match_more:
                           
                           if 'http' in links2:
                            if 'http' in links2:
                              if 'href' in links2:
                                regex_l2='href=&quot;(.+?)&quot'
                                match_le=re.compile(regex_l2).findall(links2)
                                links2=match_le[0]
                          
                              try:
                                names=re.compile('//(.+?)/',re.DOTALL).findall(links2)[0]
                              except:
                                names='Direct'
                        
                              if links2 not in all_links_only:
                                all_links_only.append(links2)
                                all_links.append((saved_name,links2,names,quality))
                                link_source1=all_links
   
          return (all_links)

def get_links(name,link,plot,data,image,saved_season,eng_name,year):
   import resolveurl,json
   global link_hdonline
   episode=name.replace("פרק ",'')
   season=saved_season.replace("עונה ",'')
   if len(episode)==1:
      episode_n="0"+episode
   else:
       episode_n=episode
   if len(season)==1:
      season_n="0"+season
   else:
      season_n=season
   if Addon.getSetting("hd")=='true':
       thread=[]
       thread.append(Thread(get_hdonline,'tv',eng_name,season_n,episode_n,season,episode,year))
       thread[0].start()
   html=read_site_html('http://www.tvil.me/'+url.replace("%",""))
   all_data=[]
   if '(' and ')' in name:
     name=name.split('(')[0]
   all_data.append(name)
   all_data.append(link)
   all_data.append(plot)
   all_data.append(data)
   all_data.append(image)
   all_data.append(saved_season)


   new_data=json.dumps(all_data)
   save_file=os.path.join(user_dataDir,"fav.txt")
   file_data=[]
   change=0

   if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
   index=0

   for items in file_data:

     if len(items)>1:
       try:
         f_item=json.loads(items)

         if data==f_item[3].encode('utf8'):
           
           file_data.pop(index)
           change=1
       except:
        pass
     index=index+1
   file_data = list(filter(lambda x : x != '\n', file_data))

   if new_data+'\n' not in file_data:
      file_data.append(new_data)
      change=1
   
   for i in range (len(file_data)-1,0,-1):
     
     if len(file_data[i])<3:
      
      file_data.pop(i)
      change=1
   if change>0:
          for i in range (len(file_data)-1,0,-1):
             file_data[i]=file_data[i].replace('\n','')
             if len(file_data[i])<3:
              
              file_data.pop(i)
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
    
   regex='(?:<div class="view-watch-button">|<div class="view-download-button">)<a href="(.+?)" target="_blank">(.+?)</a>'
   direct=[]
   direct.append(True)
   match=re.compile(regex,re.DOTALL).findall(html)
   all_names=['[COLOR aqua]ניגון אוטומטי[/COLOR]']
   all_links=['Auto']

   #links=get_hdonline('tv',eng_name,season_n,episode_n,season,episode,year)
   if Addon.getSetting("hd")=='true':
       while(thread[0].is_alive()):
         xbmc.sleep(100)
   
   for names_link,link,source,q in link_hdonline:
      link=link.replace("\n","").strip()
      if 'http' in link:
       
          try:
              hmf = resolveurl.HostedMediaFile(url=link, include_disabled=False,
                         include_universal=False)
              if hmf.valid_url() :
                direct.append(False)
              else:
                direct.append(True)
              
          except:
             direct.append(True)
        
          all_names.append('[COLOR plum][I]720p - '+ source.replace('openload','vummo')+'[/I][/COLOR]')
          all_links.append(link)
   for link,names_link in match:
      link=link.replace("\n","").strip()
      
      hmf = resolveurl.HostedMediaFile(url=link, include_disabled=False,
                 include_universal=False)
      if hmf.valid_url() :
          direct.append(False)
          all_names.append(names_link.replace('openload','vummo'))
          all_links.append(link)
   data_sp=get_sp(eng_name,name,season,episode)
   logging.warning(data_sp)
   if len (data_sp)>0:
     for name_in,link,name2,q in data_sp:
      try:
              hmf = resolveurl.HostedMediaFile(url=link, include_disabled=False,
                         include_universal=False)
              if hmf.valid_url() :
                direct.append(False)
              else:
                direct.append(True)
              
      except:
             direct.append(True)
      all_names.append('[SP] '+name2.replace('openload','vummo'))
      logging.warning(name2)
      logging.warning(link)
      all_links.append(link)
  
   return season,episode,direct,all_names,all_links
   
def play_links(name,link,plot,data,image,saved_season,eng_name,year):
   import resolveurl,json
   
   if 1:#try:
     season,episode,direct,all_names,all_links=get_links(name,link,plot,data,image,saved_season,eng_name,year)
   #except Exception as e:
      
   #   logging.warning(e)
   #   xbmcgui.Dialog().ok('Error occurred','קאש נוקה נסה שוב')
   
   #season,episode,direct,all_names,all_links=get_links(name,link,plot,data,image,saved_season,eng_name,year)
   video_data={}
   video_data['TVshowtitle']=eng_name
   video_data['mediatype']='tvshow'
   
   video_data['OriginalTitle']=eng_name
   video_data['title']=eng_name
   video_data['poster']=image
   video_data['plot']=plot
   video_data['icon']=image
   video_data['year']=year
   video_data['season']=season
   video_data['episode']=episode
   
   ret = xbmcgui.Dialog().select("בחר מקור",all_names)
   if ret!=-1:
       
       if all_links[ret]=='Auto':
        z=0
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מנגן', '','')
        dp.update(0, 'אנא המתן','מנגן', '' )

        #logging.warning(all_links)
        for links in all_links:
          if links!='Auto':
           try:
            dp.update(int(z/(len(all_links)*100.0)),links.replace('openload','vummo'),str(z)+'/'+str(len(all_links)),'')
            z=z+1
            if 'streamango' in links or 'openload' in links or 'olpair' in links or 'vidup' in links:

               direct[ret]=True
            if direct[ret]==False:
            
                hmf = resolveurl.HostedMediaFile(url=links, include_disabled=False,include_universal=False)
                link=hmf.resolve()
            else:
                 link=links
            if link==False:
              link=all_links[ret]
            if '720p - ' not in all_names[ret]:
              video_data[u'mpaa']=unicode('heb')
            if 'streamango' in links:
               x=requests.get(links).content
               regex='"description" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               link=resolve_streamango(links)
            if 'openload' in links:
               x=requests.get(links).content
               regex='"og:title" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               link=getMediaLinkForGuest(links)
            if 'thevideo' in links :
               x=requests.get(links).content
               regex='"og:title" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               link=getMediaLinkForGuest_thevid(links)[1]
               logging.warning('f_link')
               logging.warning(link)
            if 'vidup' in links :
               x=requests.get(links).content
               regex='"og:title" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               link=getMediaLinkForGuest_vidup(links)[1]
               
               
   
            listItem = xbmcgui.ListItem(name, path=link) 
            listItem.setInfo(type='Video', infoLabels=video_data)


            listItem.setProperty('IsPlayable', 'true')

            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
            while not xbmc.Player().isPlaying():
               xbmc.sleep(10) #wait until video is being played
           
            if xbmc.Player().isPlaying():
                dp.close()
                break
           except Exception as e:
             logging.warning(e)
             dp.update(int(z/(len(all_links)*100.0)),links,str(z)+'/'+str(len(all_links)),str(e))
             pass
           dp.close()
       else:
        logging.warning(all_links[ret])
        if 'streamango' in all_links[ret] or 'openload' in all_links[ret] or 'thevideo' in all_links[ret] or 'vidup' in all_links[ret]:
           
             direct[ret]=True
       
        if direct[ret]==False:
          
                hmf = resolveurl.HostedMediaFile(url=all_links[ret], include_disabled=False,
                         include_universal=False)
                link=hmf.resolve()
        else:
            link=all_links[ret]
        if 'streamango' in all_links[ret]:
               x=requests.get(all_links[ret]).content
               regex='"description" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               link=resolve_streamango(all_links[ret])
        if 'openload' in all_links[ret] :
               x=requests.get(all_links[ret]).content
               regex='"og:title" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               link=getMediaLinkForGuest(all_links[ret])
        if 'thevideo' in all_links[ret] :
               user_agent ='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0'
                
               headers = {'User-Agent': user_agent}
      
               x=requests.get(all_links[ret],headers=headers).content
               regex='"og:title" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               logging.warning(all_links[ret])
               link=getMediaLinkForGuest_thevid(all_links[ret])[1]
               logging.warning('f_link')
               logging.warning(link)
        if 'vidup' in all_links[ret] :
               x=requests.get(all_links[ret]).content
               regex='"og:title" content="(.+?)"'
               match=re.compile(regex).findall(x)
               video_data['title']=match[0]
               link=getMediaLinkForGuest_vidup(all_links[ret])[1]
        if link==False:
          link=all_links[ret]
        if '720p - ' not in all_names[ret]:
          video_data[u'mpaa']=unicode('heb')
        
        listItem = xbmcgui.ListItem(name, path=link) 
        listItem.setInfo(type='Video', infoLabels=video_data)


        listItem.setProperty('IsPlayable', 'true')

        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
       
   else:
     sys.exit()
def scrape_new(name,url,iconimage):

   if url=='http://www.tvil.me/':
      html=read_site_html('http://www.tvil.me/')
   elif url=='genere':
     html=read_site_html('http://www.tvil.me/%D7%A1%D7%93%D7%A8%D7%95%D7%AA.html')
     regex='<option value="(.+?)">(.+?)<'
     match=re.compile(regex).findall(html)
     all_names=[]
     all_links=[]
     
     for link,name in match:
        all_links.append(link)
        all_names.append(name)
        
     ret = xbmcgui.Dialog().select("בחר עונה",all_names)
     if ret!=-1:
          url='http://www.tvil.me/%s/%s/%s'%('סדרות',all_links[ret],all_names[ret])
             
       
      
          html=read_site_html(url)
          regex='<div id="link-(.+?)".+?<img src="(.+?)".+?alt="(.+?)".+?window.location = "(.+?)"'
          match=re.compile(regex,re.DOTALL).findall(html)
          for link_num,image,name,link in match:
            addDir3(name,link,2,image,image,name)
   
   else:
     html=read_site_html('http://www.tvil.me/'+url)
   if url!='genere':
       regex='<div class="index-episode-cover.+?<img src="(.+?)".+?<div class="index-episode-caption"><a href="(.+?)">(.+?)</a>'
       match=re.compile(regex,re.DOTALL).findall(html)
      
      
       for image,link,name in match:
          addLink(name,link,3,False,image,image,' ',data=name)
       regex="a class='current'>.+?</a></li><li><a href='(.+?)'>"
       match=re.compile(regex).findall(html)
       if len(match)>0:
         addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]','http://www.tvil.me/'+match[0],4,' ',' ','עמוד הבא')
def remove_to_fav(plot):
    file_data=[]
    change=0
    plot=urllib.unquote_plus(plot)
    plot_a=plot.split('$$')
    plot=json.dumps(plot_a)

    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    
    if plot in file_data:
      file_data.pop(file_data.index(plot))
      change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
          xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'נמחק')).encode('utf-8'))
          xbmc.executebuiltin('Container.Refresh')
def search():
        search_entered =''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText()
                html=read_site_html('http://www.tvil.me/%D7%A1%D7%93%D7%A8%D7%95%D7%AA.html')
                regex='<div id="link-(.+?)".+?<img src="(.+?)".+?alt="(.+?)".+?window.location = "(.+?)"'
                match=re.compile(regex,re.DOTALL).findall(html)
                for link_num,image,name,link in match:
                  if search_entered in name:
                    addDir3(name,link,2,image,image,name)
        else:
          sys.exit()
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
data=' '
eng_name=' '
year=' '
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        data=urllib.unquote_plus(params["data"])
except:
        pass
try:        
        saved_season=urllib.unquote_plus(params["saved_season"])
except:
        pass
try:        
        eng_name=urllib.unquote_plus(params["eng_name"])
except:
        pass
try:        
        year=urllib.unquote_plus(params["year"])
except:
        pass
        
if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
        scrape_site(name,url,iconimage,data)
elif mode==3:
        play_links(name,url,description,data,iconimage,saved_season,eng_name,year)
elif mode==4:
         scrape_new(name,url,iconimage)
elif mode==6:
        open_last()
elif mode==8:
        all_s(url)
elif mode==19:
        remove_to_fav(description)
elif mode==7:
        search()
xbmcplugin.setContent(int(sys.argv[1]), 'movies')


xbmcplugin.endOfDirectory(int(sys.argv[1]))

