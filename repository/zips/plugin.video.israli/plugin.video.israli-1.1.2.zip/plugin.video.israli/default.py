# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,time,xbmcvfs
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
import cache
import PTN
import requests
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)

try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database
ADDON=xbmcaddon.Addon(id='plugin.video.israli')
__PLUGIN_PATH__ = ADDON.getAddonInfo('path')
cacheFile=__PLUGIN_PATH__ + "\\resources\\sratim.db"

addonInfo = xbmcaddon.Addon().getAddonInfo
dataPath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
#cacheFile = os.path.join(dataPath, 'cache_play.db')
xbmcvfs.mkdir(dataPath)
dbcon = database.connect(cacheFile)
dbcur = dbcon.cursor()
                                                  
dbcur.execute("CREATE TABLE IF NOT EXISTS AllData ( ""name TEXT, ""url TEXT, ""icon TEXT, ""image TEXT, ""plot TEXT, ""year TEXT, ""genere TEXT, ""id TEXT, ""eng_name TEXT, ""size TEXT);" )
domain_s='https://'

try:
    dbcur.execute("VACUUM 'AllData';")
    dbcur.execute("PRAGMA auto_vacuum;")
    dbcur.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
    dbcur.execute("PRAGMA temp_store=MEMORY ;")
except:
 pass
dbcon.commit()

def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", iconimage )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok



def addLink( name, url,mode,isFolder, iconimage,fanart,description,video_data,data=''):

          u=sys.argv[0]+"?url="+urllib.quote_plus(url.encode('utf8'))+"&mode="+str(mode)+"&name="+(name.encode('utf8'))+"&data="+str(data.encode('utf8'))+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description.encode('utf8'))
 

          
         
         
          #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels=video_data)
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):
    
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    html=requests.get(url_link).content
    return html
def get_tmdb_data(eng_name,image,year,html_g):
    tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
    if year=='0':
      tmdb_data="https://api.tmdb.org/3/search/movie?api_key=%s&query=%s&year=%s&language=he&append_to_response=external_ids"%(tmdbKey,urllib.quote_plus(eng_name),year)
    else:
      tmdb_data="https://api.tmdb.org/3/search/movie?api_key=%s&query=%s&language=he&append_to_response=external_ids"%(tmdbKey,urllib.quote_plus(eng_name))
   
    all_data=requests.get(tmdb_data).json()
    id='0'
    name=eng_name
    fanart=image
    icon=image
    plot=eng_name
    if 'results' in all_data:
      if len(all_data['results'])>0:
            id=all_data['results'][0]['id']
            if (all_data['results'][0]['id'])!=None:
             
              
                try:
                        name=all_data['results'][0]['title']
                        try:
                          icon=domain_s+'image.tmdb.org/t/p/original/'+all_data['results'][0]['poster_path']
                          fanart=domain_s+'image.tmdb.org/t/p/original/'+all_data['results'][0]['backdrop_path']
                        except:
                         pass
                        plot=all_data['results'][0]['overview']
                except:
                        name=info['title']
                        fanart=' '
                        icon=' '
                        plot=' '
      else:
           
           name=eng_name
           fanart=image
           icon=image
           plot=eng_name
    else:
           
           name=eng_name
           fanart=image
           icon=image
           plot=eng_name
    genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
    if i['name'] is not None])
    try:genere = u' / '.join([genres_list[x] for x in all_data['results'][0]['genre_ids']])
    except:genere=''
    return name,icon,fanart,plot,year,genere,id
def get_genere():
    url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
    html_g=requests.get(url_g).json()
    return html_g
def main_menu():
    addDir3('כל הסרטים','www',3,'https://cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/israeli/34159-abulele_1_480x543.jpg','https://www.edb.co.il/blog/wp-content/static/2015/12/2016_israeli_films.jpg','כל הסרטים')
    addDir3('סרטים לפי קטגוריות','genere',3,'http://blog.mentor.co.il/wp-content/uploads/2013/10/video_kalt_IS_azulai.jpg','https://www.pitria.com/wp-content/uploads/2017/12/%D7%A1%D7%A8%D7%98%D7%99%D7%9D-%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99%D7%9D.jpg','סרטים לפי קטגוריות')
    addDir3('סרטים לפי שנים','year',3,'https://img.mako.co.il/2017/11/23/zeev_i.jpg','https://www.edb.co.il/photos/291912015_publicity09.news.jpg','סרטים לפי שנים')
    addDir3('לפי א-ב','byalpha',3,'https://www.makorrishon.co.il/nrg/images/archive/300x225/1/472/582.jpg','https://images1.ynet.co.il/PicServer4/2015/05/28/6079280/607862918920100640360no.jpg','לפי א-ב')
    addDir3('[COLOR aqua][I] חיפוש [/I][/COLOR]','search',3,'https://img.mako.co.il/2017/11/23/zeev_i.jpg','https://www.edb.co.il/photos/291912015_publicity09.news.jpg','חיפוש')
    html=read_site_html('https://files.fm/u/c3m3xd3b#/list/')
    for i in range (0,2):
        if i==1:
          
          html=read_site_html('https://files.fm/u/pfbtgqjk#/list/')
        regex='arrDisplayNames = \[(.+?)\]'
        names=re.compile(regex).findall(html)[0].split(",")
        regex='var arrHashes = \[(.+?)\]'
        links=re.compile(regex).findall(html)[0].split(",")
        regex='var arrThumbnails = \[(.+?)\]'
        images=re.compile(regex).findall(html)[0].split(",")
        html_g=cache.get(get_genere,72, table='pages')
        regex='var arrSizes = \[(.+?)\]'
        sizes=re.compile(regex).findall(html)[0].split(",")
        dp = xbmcgui.DialogProgress()
        dp.create("טוען סרטים", "אנא המתן", '')
        dp.update(0)
        all_one=[]
        for i in range (0,len(names)-1):
          all_one.append((names[i].replace('"','').replace('\\','').replace('נתי מדיה ',''),links[i].replace('"',''),images[i].replace('"',''),sizes[i].replace('"','')))
        xxx=0
        start_time=time.time()
        
        for name,link,image,size in all_one:
          elapsed_time = time.time() - start_time

          info=(PTN.parse(name))
          if info['title']=='' and 'excess' in info:
      
            if type (info['excess']) is list:
              info['title']=info['excess'][0]
            else:
              info['title']=info['excess']
          if dp.iscanceled():
            break
          f_link='https://fv5.failiem.lv/down.php?i=%s&n=%s'%(link,name)
         
          dbcur.execute("SELECT * FROM AllData WHERE eng_name = '%s'"%(info['title'].replace("'"," ")))
        
     
          match = dbcur.fetchone()
          if 'year' in info:
            year=str(info['year'])
          else:
            year='0'
          if match==None:
 
            name,icon,image,plot,year,genere,id=get_tmdb_data(info['title'],image,year,html_g)
   
            dbcur.execute("INSERT INTO AllData Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s');"%(name.replace("'"," "),f_link.replace("'","%27"),icon,image,plot.replace("'"," "),year,genere.replace("'"," "),id,info['title'].replace("'"," "),size))
            dbcon.commit()
          else:
            name,f_link,icon,image,plot,year,genere,id,eng_name,size= match
          dp.update(int(((xxx* 100.0)/(len(all_one))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'[COLOR aqua]'+name+'[/COLOR]')
          xxx=xxx+1
     

    dp.close()
def get_movies(url):
      if url=='genere':
        html_g=cache.get(get_genere,72, table='pages')
        all_generes=[]
        for items in html_g['genres']:
          all_generes.append(items['name'])
        all_generes.sort()
  
        ret = xbmcgui.Dialog().select("בחר קטגוריה", all_generes)
        if ret!=-1:
          dbcur.execute("SELECT * FROM AllData WHERE genere like '%s'"%(all_generes[ret]))
        else:
          sys.exit()
      elif url=='year':
        import datetime
        now = datetime.datetime.now()
        all_years=[]
        for i in range(now.year,1950,-1):
          all_years.append(str(i))
        ret = xbmcgui.Dialog().select("בחר קטגוריה", all_years)
        if ret!=-1:
          dbcur.execute("SELECT * FROM AllData WHERE year = '%s'"%(all_years[ret]))
        else:
          sys.exit()
      elif url=='byalpha':
        all_letters_d=['1-2','א','ב','ג','ד','ה','ו','ז','ח','ט','י','כ','ל','מ','נ','ס','ע','פ','צ','ק','ר','ש','ת']
        all_letters=['1-2','\x90', '\x91', '\x92', '\x93', '\x94', '\x95', '\x96', '\x97', '\x98', '\x99', '\x9b', '\x9c', '\x9e', '\xa0', '\xa1', '\xa2', '\xa4', '\xa6', '\xa7', '\xa8', '\xa9', '\xaa']
        ret = xbmcgui.Dialog().select("בחר אות", all_letters_d)
        if ret!=-1:
          dbcur.execute("SELECT * FROM AllData WHERE name like '{0}%'".format(all_letters_d[ret]))
        else:
          sys.exit()
      elif url=='search':
        search_entered =''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText()
                dbcur.execute("SELECT * FROM AllData WHERE name like '%{0}%'".format(search_entered))
              
      else:
        dbcur.execute("SELECT * FROM AllData ")

      match = dbcur.fetchall()
      for name,f_link,icon,image,plot,year,genere,id,eng_name,size in match:
        
          video_data={}
      
          fixed_name=name
          original_title=name
          video_data['mediatype']='movies'
          video_data['OriginalTitle']=name.replace('%20',' ').replace('%3a',':').replace('%27',"'")
          video_data['title']=fixed_name
          video_data['poster']=image
          video_data['plot']=plot
          video_data['icon']=icon
          video_data['year']=year
          video_data['genre']=genere
          video_data[u'mpaa']=unicode('heb')
          addLink( name, f_link,2,False, icon,image,year+'\n'+size.replace('&nbsp;',' ')+'\n'+plot,video_data)
def play(name,url,description):
    urls=url.split('n=')
    url2=urllib.quote_plus(urls[len(urls)-1])
    url=url.replace(urls[len(urls)-1],url2)
    video_data={}
  
    fixed_name=name
    original_title=name
    video_data['mediatype']='movies'
    video_data['OriginalTitle']=original_title.replace('%20',' ').replace('%3a',':').replace('%27',"'")
    video_data['title']=fixed_name
    video_data[u'mpaa']=unicode('heb')
    video_data['plot']=description



    listItem = xbmcgui.ListItem(video_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=video_data)


    listItem.setProperty('IsPlayable', 'true')

   
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
       play(name,url,description)
elif mode==3:
       get_movies(url)
xbmcplugin.setContent(int(sys.argv[1]), 'movies')


xbmcplugin.endOfDirectory(int(sys.argv[1]))

